from django.shortcuts import render
from django.http import JsonResponse
from .models import Post
from .apps import TSRConfig

# import the necessary packages
from skimage import transform
from skimage import exposure
from skimage import io
import numpy as np
from tensorflow.keras.models import load_model
import tensorflow as tf
global graph

labelNames = open("signnames.csv").read().strip().split("\n")[1:]
labelNames = [l.split(",")[1] for l in labelNames]

# Create your views here.

def create_post(request):
    postsdata = Post.objects.all()
    response_data = {}

    if request.POST.get('action') == 'post':
        imagepath =request.POST.get('image')
        
        # just like we did during training
            
        image = io.imread("Test/"+imagepath)
        image = transform.resize(image, (32, 32))
        image = exposure.equalize_adapthist(image, clip_limit=0.1)
        # preprocess the image by scaling it to the range [0, 1]
        image = image.astype("float32") / 255.0
        image = np.expand_dims(image, axis=0)
    
        # make predictions using the traffic sign recognizer CNN
        
        preds = TSRConfig.model.predict(image)
        j = preds.argmax(axis=1)[0]
        label = labelNames[j]
        
        response_data['description'] = label
      
        Post.objects.create(
            title = 'Title',
            description = 'description',
            )
        return JsonResponse(response_data)

    return render(request, 'create_post.html', {'postsdata':postsdata})    

def test_post(req):
    return render(req,'test_post.html')    

    