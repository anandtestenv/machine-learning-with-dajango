from django.apps import AppConfig
from tensorflow.keras.models import load_model
import tensorflow as tf
global graph

class TSRConfig(AppConfig):
    name = 'Traffic Sign Recognition'
    model = load_model("traffic_sign_classification_30EPC_97Acc.model")
    model._make_predict_function()
    graph = tf.get_default_graph()
